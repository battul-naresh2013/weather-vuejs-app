const mutations = {
  SET_WEATHER_DETAILS(state, weatherDetails) {
    state.weatherDetails = weatherDetails;
  },
};

export default mutations;
