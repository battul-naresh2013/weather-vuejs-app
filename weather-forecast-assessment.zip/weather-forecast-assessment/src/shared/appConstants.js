export const apiKey = '099a7c33c1be08ed21d565feaedb1fd4';
export const cityApiUrl = '/data/2.5/forecast?id';
export const actionTypes = {
  getWeatherDetailsAction: 'weatherForecastModule/getWeatherDetailsAction',
  addNotification: 'notification/add',
  getNotification: 'notification/get',
  clearNotification: 'notification/clear',
};
